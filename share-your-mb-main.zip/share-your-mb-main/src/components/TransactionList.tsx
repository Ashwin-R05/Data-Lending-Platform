import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownLeft, History } from "lucide-react";

interface Transaction {
  id: string;
  type: "sent" | "received";
  amount: number;
  unit: "MB" | "GB";
  contact: string;
  date: string;
  status: "completed" | "pending";
}

const sampleTransactions: Transaction[] = [
  {
    id: "1",
    type: "sent",
    amount: 500,
    unit: "MB",
    contact: "Sarah Johnson",
    date: "2 hours ago",
    status: "completed",
  },
  {
    id: "2",
    type: "received",
    amount: 1,
    unit: "GB",
    contact: "Michael Chen",
    date: "Yesterday",
    status: "completed",
  },
  {
    id: "3",
    type: "sent",
    amount: 250,
    unit: "MB",
    contact: "Emma Wilson",
    date: "2 days ago",
    status: "completed",
  },
];

export const TransactionList = () => {
  return (
    <Card className="border border-primary/30 bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm hover:shadow-[var(--shadow-elegant)] transition-all duration-300">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="w-5 h-5 text-primary" />
          Recent Activity
        </CardTitle>
        <CardDescription>
          Your data sharing history
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sampleTransactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between p-4 rounded-lg border border-border/50 bg-card/30 hover:border-primary/40 hover:bg-card/50 transition-all duration-200"
            >
              <div className="flex items-center gap-4">
                <div
                  className={`p-2 rounded-full ${
                    transaction.type === "sent"
                      ? "bg-destructive/10 text-destructive"
                      : "bg-accent/10 text-accent"
                  }`}
                >
                  {transaction.type === "sent" ? (
                    <ArrowUpRight className="w-5 h-5" />
                  ) : (
                    <ArrowDownLeft className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <p className="font-medium text-foreground">{transaction.contact}</p>
                  <p className="text-sm text-muted-foreground">{transaction.date}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-foreground">
                  {transaction.type === "sent" ? "-" : "+"}
                  {transaction.amount} {transaction.unit}
                </p>
                <Badge
                  variant={transaction.status === "completed" ? "default" : "secondary"}
                  className="mt-1"
                >
                  {transaction.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
