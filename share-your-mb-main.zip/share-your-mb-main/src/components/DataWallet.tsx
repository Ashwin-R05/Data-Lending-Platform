import { Card } from "@/components/ui/card";
import { Database, TrendingUp, TrendingDown } from "lucide-react";

interface DataWalletProps {
  balance: number;
  unit: "MB" | "GB";
}

export const DataWallet = ({ balance, unit }: DataWalletProps) => {
  return (
    <Card className="relative overflow-hidden border border-primary/30 bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm p-8 hover:border-primary/50 hover:shadow-[var(--shadow-glow)] transition-all duration-300">
      <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full -mr-32 -mt-32 blur-3xl" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-accent/15 to-primary/15 rounded-full -ml-24 -mb-24 blur-3xl" />
      
      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-2">
          <Database className="w-5 h-5 text-foreground" />
          <span className="text-sm font-medium uppercase tracking-wide text-muted-foreground">Your Data Balance</span>
        </div>
        
        <div className="flex items-baseline gap-2 mb-6">
          <span className="text-6xl font-bold tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{balance}</span>
          <span className="text-3xl font-semibold text-primary-glow">{unit}</span>
        </div>

        <div className="flex gap-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-accent" />
            <span className="text-sm text-muted-foreground">Ready to share</span>
          </div>
          <div className="flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">0% used this month</span>
          </div>
        </div>
      </div>
    </Card>
  );
};
