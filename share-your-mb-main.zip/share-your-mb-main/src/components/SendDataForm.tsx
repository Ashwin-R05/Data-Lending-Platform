import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Send } from "lucide-react";
import { toast } from "sonner";

export const SendDataForm = () => {
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [unit, setUnit] = useState("MB");

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!recipient || !amount) {
      toast.error("Please fill in all fields");
      return;
    }

    const numAmount = parseFloat(amount);
    if (numAmount <= 0) {
      toast.error("Amount must be greater than 0");
      return;
    }

    toast.success(`Successfully sent ${amount}${unit} to ${recipient}`, {
      description: "Your data has been transferred instantly",
    });

    setRecipient("");
    setAmount("");
  };

  return (
    <Card className="border border-primary/30 bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm hover:border-primary/50 hover:shadow-[var(--shadow-glow)] transition-all duration-300">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Send className="w-5 h-5 text-primary" />
          Send Data
        </CardTitle>
        <CardDescription>
          Share your data balance with anyone, anywhere
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSend} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="recipient">Recipient</Label>
            <Input
              id="recipient"
              placeholder="Phone number or email"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="transition-all duration-200 focus:shadow-sm"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Amount</Label>
            <div className="flex gap-2">
              <Input
                id="amount"
                type="number"
                min="0"
                step="0.1"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="flex-1 transition-all duration-200 focus:shadow-sm"
              />
              <Select value={unit} onValueChange={setUnit}>
                <SelectTrigger className="w-24">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MB">MB</SelectItem>
                  <SelectItem value="GB">GB</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-primary to-accent hover:shadow-[var(--shadow-glow)] transition-all duration-300"
          >
            <Send className="w-4 h-4 mr-2" />
            Send Data
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};
