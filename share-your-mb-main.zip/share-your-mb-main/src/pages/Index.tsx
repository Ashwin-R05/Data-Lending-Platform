import { DataWallet } from "@/components/DataWallet";
import { SendDataForm } from "@/components/SendDataForm";
import { TransactionList } from "@/components/TransactionList";
import { Share2, Smartphone, Heart } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-card/20">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/80 backdrop-blur-xl sticky top-0 z-50 shadow-lg shadow-primary/5">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-primary to-accent rounded-xl shadow-[var(--shadow-glow)] animate-pulse">
              <Share2 className="w-6 h-6 text-background" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary via-accent to-primary-glow bg-clip-text text-transparent">
                DataShare
              </h1>
              <p className="text-sm text-muted-foreground">Share connectivity, spread kindness</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Hero Section */}
        <section className="mb-12 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-primary-glow bg-clip-text text-transparent">
            Lend Data. Stay Connected.
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Transform unused mobile data into instant help for friends, family, and anyone who needs it
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mt-8 max-w-4xl mx-auto">
            <div className="group p-6 rounded-2xl bg-gradient-to-br from-card/80 to-card/40 border border-primary/20 backdrop-blur-sm hover:border-primary/50 hover:shadow-[var(--shadow-glow)] transition-all duration-300">
              <Smartphone className="w-12 h-12 text-primary mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="font-semibold mb-2">Instant Transfer</h3>
              <p className="text-sm text-muted-foreground">Send data in seconds, anywhere in the world</p>
            </div>
            <div className="group p-6 rounded-2xl bg-gradient-to-br from-card/80 to-card/40 border border-accent/20 backdrop-blur-sm hover:border-accent/50 hover:shadow-[var(--shadow-accent)] transition-all duration-300">
              <Share2 className="w-12 h-12 text-accent mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="font-semibold mb-2">Zero Waste</h3>
              <p className="text-sm text-muted-foreground">Never let your data quota expire unused</p>
            </div>
            <div className="group p-6 rounded-2xl bg-gradient-to-br from-card/80 to-card/40 border border-primary/20 backdrop-blur-sm hover:border-primary/50 hover:shadow-[var(--shadow-glow)] transition-all duration-300">
              <Heart className="w-12 h-12 text-primary-glow mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="font-semibold mb-2">Make a Difference</h3>
              <p className="text-sm text-muted-foreground">Help students, families, and communities thrive</p>
            </div>
          </div>
        </section>

        {/* Dashboard Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <DataWallet balance={3.5} unit="GB" />
            <TransactionList />
          </div>
          
          <div className="lg:col-span-1">
            <SendDataForm />
          </div>
        </div>

        {/* Footer Info */}
        <section className="mt-16 p-8 rounded-2xl bg-gradient-to-br from-card/60 to-card/30 border border-primary/20 backdrop-blur-sm shadow-[var(--shadow-elegant)]">
          <h3 className="text-2xl font-bold mb-4 text-center bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Why DataShare?</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm text-muted-foreground">
            <div>
              <p className="mb-2">✓ Secure & encrypted transfers</p>
              <p className="mb-2">✓ Works across all carriers</p>
              <p className="mb-2">✓ International support</p>
            </div>
            <div>
              <p className="mb-2">✓ Real-time balance updates</p>
              <p className="mb-2">✓ Complete transaction history</p>
              <p className="mb-2">✓ Instant connectivity help</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Index;
